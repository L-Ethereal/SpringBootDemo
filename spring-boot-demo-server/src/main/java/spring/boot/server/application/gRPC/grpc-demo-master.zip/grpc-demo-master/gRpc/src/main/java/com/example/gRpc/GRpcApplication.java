package com.example.gRpc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GRpcApplication {

	public static void main(String[] args) {
		SpringApplication.run(GRpcApplication.class, args);
	}
}
